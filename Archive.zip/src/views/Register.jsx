import React from 'react'

import '../assets/styles/Login.css'

const Register = () => {
    return (
        <div className='login'>
            <div className="container">
                <div className="flex flex-col space-y-3 mb-8">
                    <p className='text-4xl font-bold'> ¡Bienvenido! </p>
                    <p className=''> Agradecemos mucho tus ganas de colaborar </p>
                </div>

                <input type="text" placeholder='Nombre(s)' />
                <input type="text" placeholder='Apellidos' />

                <input type="email" placeholder='correo@ipn.mx' />

                <input type="password" placeholder='Contraseña' />
                <input type="password" placeholder='Repite tu contraseña' />

                <div className="flex justify-between items-center px-4">
                    <div className='flex items-center space-x-3'>
                        <input type="checkbox" name="record" id="record" />
                        <label htmlFor="record"> Recordarme </label>
                    </div>
                    <p> Olvide mi contraseña </p>
                </div>

                <button className=''> Iniciar </button>
            </div>

            <div className="bg">
            </div>
        </div>
    )
}

export default Register