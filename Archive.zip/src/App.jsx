import React, {useEffect, useState} from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';

import Home from './views/Home'
import View from './views/View'
import Login from './views/Login'

import './assets/styles/App.css'

const App = () => {
    const location = useLocation()
    const [isHidden, setIsHidden] = useState(false)

    useEffect(() => {
        if (location.pathname === '/login') {
          setIsHidden(true);
        } else {
          setIsHidden(false);
        }
      }, [location.pathname]);
    
    return (
        <div>
            <nav className={`flex justify-around items-center text-xl p-5 ${isHidden ? 'hidden' : ''}`}>
                <div className="flex justify-around items-center w-1/3">
                    <Link to="/"> <i className='icon-home'></i> <p className='hidden lg:inline'>Home</p> </Link>
                    <Link to="/view"> <i className='icon-library'></i> <p className='hidden lg:inline'>View</p> </Link>
                </div>
                <div>
                    <Link to="/login"> <i className='icon-user'></i> Iniciar </Link>
                </div>
            </nav>
            <Routes>
                <Route path="/" element={<Home />} />
                <Route path="/view" element={<View />} />
                <Route path="/login" element={<Login />} />
            </Routes>
        </div>
    );
};

export default App;
